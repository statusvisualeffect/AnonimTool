# КАК ИСПОЛЬЗОВАТЬ:

Установите git https://git-scm.com/downloads
Установите python 3.8.0 https://www.python.org/ftp/python/3.8.0/python-3.8.0-amd64.exe
Откройте ru.exe
Выберите опцию "Install lib"
Подождите...
Нажмите Enter и выберите опцию "Start Anonim Tool"
Наслаждайтесь!

# КАК ОТКЛЮЧИТЬ ЗАГРУЗЧИК:

Перейдите в "C:\AnonimTool"
Найдите файл с именем "loader_disable"
Переименуйте его в "loader_disable.txt"
Наслаждайтесь!

# КАК ВКЛЮЧИТЬ ЗАГРУЗЧИК:

Перейдите в "C:\AnonimTool"
Найдите файл с именем "loader_disable.txt"
Переименуйте его в "loader_disable"
Наслаждайтесь!

# КАК УДАЛИТЬ Anonim Tool:

Перейдите в "C:\AnonimTool"
Найдите файл с именем "uninstall.exe"
Откройте его
Теперь вы успешно удалили Anonim Tool
