# HOW TO USE:

1. Install git https://git-scm.com/downloads
2. Install python 3.8.0 https://www.python.org/ftp/python/3.8.0/python-3.8.0-amd64.exe
3. Open Anonim.exe
4. Choice option "Install lib"
5. Wait...
6. Press enter and choice option "Start anonim tool"
7. Enjoy!

# HOW TO DISABLE LOADER:

1. Go to "C:\AnonimTool"
2. Find file named "loader_disable"
3. Rename it to "loader_disable.txt"
4. Enjoy!

# HOW TO ENABLE LOADER:

1. Go to "C:\AnonimTool"
2. Find file named "loader_disable.txt"
3. Rename it to "loader_disable"
4. Enjoy!

# HOW TO DELETE ANONIM TOOL:

1. Go to "C:\AnonimTool"
2. Find file named "uninstall.exe"
3. Open it
4. Now you successfully uninstalled anonim tool
